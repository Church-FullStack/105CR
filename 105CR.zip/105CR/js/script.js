// OBJECT LITERAL

const salon = {
    name: "Paw Beans Pet Salon",
    phone: "5551234567",
    address:{
        street: "Paw Ave.",
        number: "1549 Suite F"
    },
    operatingHours:{
        days: "Mon-Fri",
        open: "9AM",
        close: "9PM"
    },
    pets:[],
    count:function(){
        alert("You are registered! " + this.pets.length + "pets have been registered.");
    }
}
// object destructor

let {name,phone,address:{street,number},operatingHours:{days,open,close}} = salon;

//display the information of the salon in HTML main

//create a div with ID to select element and display + use innerHTML
document.getElementById("opinfo").innerHTML= `<h2> Welcome to ${name}!</h2>
<p>Phone: ${phone}</p><p>Adress: ${number}, ${street}</p><p>Operating Hours: ${days}:${open}-${close}</p>`;

let x=0;
class Pet{
    constructor(name,age,gender,breed,service,oName,oPhone){
        this.name = name,
        this.age = age,
        this.gender = gender;
        this.breed = breed;
        this.service = service,
        this.oName = oName,
        this.oPhone = oPhone;
        this.id = "pet"+x;
        x+=1;
    }
    ownerInfo = function(){
        console.log(`${this.oName} ${this.oPhone}`);
    }
}
//create pets simple
const scooby = new Pet("Scoobs","25","Male","Dane","Full Service","Shaggy","1234567");
salon.pets.push(scooby);
displayList(scooby);
scooby.ownerInfo();

scooby.ownerInfo();
//create register function

let txtName = document.getElementById("petName");
let txtAge = document.getElementById("petAge");
let txtGender = document.getElementById("petGender");
let txtBreed = document.getElementById("breed");
let txtService = document.getElementById("petService");
let txtOwner = document.getElementById("ownerName");
let txtOwnerContact = document.getElementById("ownerContact");


function register(){  //ADD AN ID TO THE CONSTRUCTOR + INCREMENT

    let thePet = new Pet(txtName.value,txtAge.value,txtGender.value,txtBreed.value,txtService.value,txtOwner.value,txtOwnerContact.value);
    console.log(thePet);
    //take values from HTML form

    //create pet
salon.pets.push(thePet);
displayList(thePet);
    //display in HTML
    clear();
}
function displayList(aPet){
    let listBody = document.getElementById("rowPet");
    let item = ` 
    <tr id="${aPet.id}">
    <td>${aPet.name}</td> 
    <td>${aPet.age}</td> 
    <td>${aPet.gender}</td> 
    <td>${aPet.breed}</td> 
    <td>${aPet.service}</td>
    <td>${aPet.oName}</td> 
    <td>${aPet.oPhone}</td>
    <td> <button onclick='deletePet("${aPet.id}");'>Delete</button></td>
    `;
    listBody.innerHTML+=item;
   
}
function deletePet(petID){
    let row = document.getElementById(petID);
    let indexDelete;
    for(let i=0;i<salon.pets.length;i++){
        let selected = salon.pets[i];
        if(petID===selected.id){
            indexDelete=i;
        }

    }
    salon.pets.splice(indexDelete,1);
    row.remove();
}



function clear(){
    txtName.value = " "; 
    txtAge.value =" ";
    txtGender.value = " ";
    txtBreed.value = " ";
    txtService.value = " ";
    txtOwner.value = " ";
    txtOwnerContact.value = " ";
}

function searchPet(){
    let searchString = document.getElementById('txtSearch').value;
    let ss=searchString.toLowerCase();
    for(let j=0;j<salon.pets.length;j++){
        let searched = salon.pets[j];
        if(ss===searched.id || ss===searched.service.toLowerCase() || ss===searched.name.toLowerCase()){
            document.getElementById('pet'+j).setAttribute('class','selected');
        }
    }

}